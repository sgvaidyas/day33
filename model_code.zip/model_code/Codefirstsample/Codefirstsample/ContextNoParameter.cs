﻿using System;
using System.Data.Entity;

namespace Codefirstsample
{
    class ContextNoParameter : DbContext
    {
        public ContextNoParameter():base("name=mydb")
        {

        }
        public virtual DbSet<Student> Students { get; set; }
    }
}
