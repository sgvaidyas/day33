﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Codefirstsample
{
    class Program
    {
        static void Main(string[] args)
        {
            ContextNoParameter db = new ContextNoParameter();
            Student s = new Student();
            s.Id = 111;
            s.Studentname = "AAAA";
            s.Studentemail = "abc@gmail.com";
            db.Students.Add(s);
            db.SaveChanges();
        }
    }
}
