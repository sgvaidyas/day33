
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 07/08/2021 11:34:06
-- Generated from EDMX file: D:\EdurekaFullStack\training\day33\Modelfirst\ModelFirst\ModelFirst\MyModelFirst.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [ModelFirstDB];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Applicants'
CREATE TABLE [dbo].[Applicants] (
    [ApplicantId] int IDENTITY(1,1) NOT NULL,
    [ApplicantName] nvarchar(max)  NOT NULL,
    [Phone] nvarchar(max)  NOT NULL,
    [Age] int  NOT NULL,
    [Accountnumber] nvarchar(max)  NOT NULL,
    [BankBankId] int  NOT NULL
);
GO

-- Creating table 'Banks'
CREATE TABLE [dbo].[Banks] (
    [BankId] int IDENTITY(1,1) NOT NULL,
    [BankName] nvarchar(max)  NOT NULL,
    [BranchName] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [ApplicantId] in table 'Applicants'
ALTER TABLE [dbo].[Applicants]
ADD CONSTRAINT [PK_Applicants]
    PRIMARY KEY CLUSTERED ([ApplicantId] ASC);
GO

-- Creating primary key on [BankId] in table 'Banks'
ALTER TABLE [dbo].[Banks]
ADD CONSTRAINT [PK_Banks]
    PRIMARY KEY CLUSTERED ([BankId] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [BankBankId] in table 'Applicants'
ALTER TABLE [dbo].[Applicants]
ADD CONSTRAINT [FK_BankApplicant]
    FOREIGN KEY ([BankBankId])
    REFERENCES [dbo].[Banks]
        ([BankId])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BankApplicant'
CREATE INDEX [IX_FK_BankApplicant]
ON [dbo].[Applicants]
    ([BankBankId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------